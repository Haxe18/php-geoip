mod debian/geoip.ini
